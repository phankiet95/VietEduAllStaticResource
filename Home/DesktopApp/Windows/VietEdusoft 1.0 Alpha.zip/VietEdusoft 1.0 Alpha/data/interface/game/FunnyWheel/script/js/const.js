window.mediaPanel = `
<div class="questionFile">
  <label class="uploadBtn mediaIcon" data-toggle="tooltip" title="Media file">
    <input class="uploadFile" type="file" accept="audio/*,video/*,image/*" data-question-id="">
    <span style="font-size: 26px;">
      <i class="fa-solid fa-file-video"></i>
    </span>
  </label>

  <label class="mediaIcon d-none mediaCancel" data-toggle="tooltip" title="Hủy media file">
    <span style="font-size: 21px;">
      <i class="fa-solid fa-ban"></i>
    </span>
  </label>
</div>`;

window.questionPanel = `
  <div class="question">
    <div class="input-group mr-sm-2">
      <div class="input-group-prepend">
        <div class="input-group-text">
          <strong>1</strong>
        </div>
      </div>
      <textarea type="text" class="form-control inputQuestion" placeholder="Câu hỏi" rows="3"></textarea>
      ${mediaPanel}
    </div>
    <div class="input-group mr-sm-2 mt-2">
      <input type="text" class="form-control inputAnswer" placeholder="Đáp án">
    </div>
  </div>`;
window.setting = {
  countdown: 30,
  font: { fontFamily: 'Arial', fontSize: 38 },
  gameinfo: {name: 'FunnyWheels'},
};
