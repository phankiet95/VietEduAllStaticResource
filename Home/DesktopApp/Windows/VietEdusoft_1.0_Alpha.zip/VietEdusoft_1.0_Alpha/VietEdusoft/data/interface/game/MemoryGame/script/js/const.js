window.questionPanel = `<div class="question"><div class="mt-2"><div class="input-group mr-sm-2"><div class="input-group-prepend"><div class="input-group-text"><strong>1</strong></div></div><input type="text" class="form-control inputQuestion" placeholder="Từ khóa"><div class="input-group-append"><label class="uploadBtn input-group-text d-block"><input class="uploadFile" type="file" accept="image/*"><img src="http://vietedusoft.weebly.com/uploads/2/6/2/2/26226810/plus_orig.png" title="Chọn hình ảnh"></label></div></div></div></div>`;
window.setting = {
  countdown: 0,
  font: { fontFamily: 'Arial', fontSize: 28 },
  background: { type: 'gradient', color: ['#89f7fe', '#66a6ff'] },
  cell: { color: '#262626', bgColor: '#ffffff60', pair: 8 },
  gameinfo: {name: 'MemoryGame'},
  gameIntro: {gameIntro_title:'', gameIntro_detail:''},
};
