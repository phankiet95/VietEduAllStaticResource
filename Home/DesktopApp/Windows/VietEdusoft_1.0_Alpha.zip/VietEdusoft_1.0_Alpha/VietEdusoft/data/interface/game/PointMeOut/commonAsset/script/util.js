window.toBase64 = (file, onload) => {
  var reader = new FileReader();
  reader.onload = function () {
    var base64 = reader.result.replace('data:', '').replace(/^.+,/, '');
    onload(base64);
  };
  reader.readAsDataURL(file);
};
window.download = (filename, text) => {
  var element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);
  element.style.display = 'none';
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
};
Array.prototype.shuffle = function () {
  let m = this.length,
    i;
  while (m) {
    i = (Math.random() * m--) >>> 0;
    [this[m], this[i]] = [this[i], this[m]];
  }
  return this;
};
