$(document).on('change', '#setupPanel .basic .color', function () {
    setting.font.color = $(this).val();
    $('.questionPreview').css('color', setting.font.color)
});