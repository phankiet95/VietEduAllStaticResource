window.questionPanel = '<div class="question"><div class="input-group mr-sm-2"><div class="input-group-prepend"><div class="input-group-text"><strong>1</strong></div></div><input type="text" class="form-control inputQuestion" placeholder="Từ sai"></div><div class="input-group mr-sm-2 mt-2"><input type="text" class="form-control inputAnswer" placeholder="Đáp án"></div></div>';
window.setting = {
  countdown: 0,
  font: { fontFamily: 'Arial', fontSize: 30, color: '#FFFFFF'},
  gameinfo: {name: 'PointMeOut'},
  gameIntro: {gameIntro_title:'', gameIntro_detail:''}
};